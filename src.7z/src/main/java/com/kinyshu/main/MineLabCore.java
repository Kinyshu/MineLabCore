package com.kinyshu.main;

import com.kinyshu.api.command.CommandProcessor;
import io.papermc.paper.plugin.lifecycle.event.LifecycleEventManager;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public final class MineLabCore extends JavaPlugin {

    private static CommandProcessor commandHandler;

    public static CommandProcessor getCommandHandler() {
        return MineLabCore.commandHandler;
    }

    private void setCommandHandler(CommandProcessor commandHandler) {
        MineLabCore.commandHandler = commandHandler;
    }

    @Override
    public void onLoad() {

        this.getLogger().log(Level.INFO, "Загружаю ядро.");
        this.getLogger().log(Level.INFO, "Сохраняю конфигурацию.");
        this.saveDefaultConfig();

        this.getLogger().log(Level.INFO, "Регистрирую обработчик команд");
        this.setCommandHandler(new CommandProcessor());
        this.getLogger().log(Level.INFO, "Обработчик команд зарегистрирован");
    }

    @Override
    public void onEnable() {
        this.getLogger().log(
                Level.INFO,
                String.format("Загрузка ядра завершена")
        );
    }

    @Override
    public void onDisable() {
    }
}
