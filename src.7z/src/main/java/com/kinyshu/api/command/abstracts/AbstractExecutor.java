package com.kinyshu.api.command.abstracts;

import com.kinyshu.api.command.argument.CommandArgument;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

import java.util.logging.Level;

public abstract class AbstractExecutor extends Command {

    private AbstractCommand command;

    public AbstractExecutor(AbstractCommand command) {
        super(command.getName(), command.getDescription(), command.getUsage(), command.getAliases());
        this.setCommand(command);

        this.getCommand().getJavaPlugin().getLogger().log(
                Level.INFO,
                String.format("Функция /%s успешно зарегистрирована.", this.getName())
        );
    }

    public AbstractCommand getCommand() {
        return this.command;
    }

    public void setCommand(AbstractCommand command) {
        this.command = command;
    }

    @Override
    public boolean execute(CommandSender sender, @NotNull String commandLabel, String[] args) {
        return onCommandExecuted(new CommandArgument(sender, commandLabel, args));
    }

    public abstract boolean onCommandExecuted(CommandArgument commandArgument);
}
