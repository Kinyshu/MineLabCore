package com.kinyshu.api.command;

import com.kinyshu.api.command.abstracts.AbstractCommand;
import org.bukkit.command.CommandMap;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

public class CommandProcessor {

    private final Map<String, AbstractCommand> commandsMap;

    public CommandProcessor() {
        this.commandsMap = new HashMap<>();
    }

    public AbstractCommand getCommand(String commandName) {
        return this.commandsMap.get(commandName);
    }

    private Map<String, AbstractCommand> getCommandsMap() {
        return this.commandsMap;
    }

    public boolean registerCommand(AbstractCommand abstractCommand) {

        if (this.getCommandsMap().get(abstractCommand.getName()) != null) {
            abstractCommand.getJavaPlugin().getLogger().log(Level.WARNING, "Попытка зарегистрировать команду, " + abstractCommand.getName() + " уже существует.");
            return false;
        }

        CommandMap commandMap = this.getCommandMap(abstractCommand.getJavaPlugin());
        if (commandMap == null) {
            return false;
        }

        boolean register = commandMap.register(abstractCommand.getName(), abstractCommand.getExecutor());
        if (register) {
            this.getCommandsMap().put(abstractCommand.getName(), abstractCommand);
        }

        return register;
    }

    public boolean unregisterCommand(AbstractCommand abstractCommand) {

        CommandMap commandMap = this.getCommandMap(abstractCommand.getJavaPlugin());
        if (commandMap == null) {
            return false;
        }

        boolean unregister = abstractCommand.getExecutor().unregister(commandMap);
        if (unregister) {
            this.getCommandsMap().remove(abstractCommand.getName());
        }

        return unregister;
    }

    public boolean unregisterCommand(String commandName) {

        AbstractCommand abstractCommand = this.getCommand(commandName);

        CommandMap commandMap = this.getCommandMap(abstractCommand.getJavaPlugin());
        if (commandMap == null) {
            return false;
        }

        boolean unregister = abstractCommand.getExecutor().unregister(commandMap);
        if (unregister) {
            this.getCommandsMap().remove(abstractCommand.getName());
        }

        return unregister;
    }

    private CommandMap getCommandMap(JavaPlugin javaPlugin) {
        try {
            Field declaredField = javaPlugin.getServer().getClass().getDeclaredField("commandMap");
            declaredField.setAccessible(true);

            return (CommandMap) declaredField.get(javaPlugin.getServer());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }
}
