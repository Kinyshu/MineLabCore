package com.kinyshu.api.command.abstracts;

import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public abstract class AbstractCommand {

    private AbstractExecutor executor;
    private String name;
    private String description;
    private String usage;
    private List<String> aliases;
    private JavaPlugin javaPlugin;

    public AbstractCommand(JavaPlugin javaPlugin) {
        this.setJavaPlugin(javaPlugin);
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUsage() {
        return this.usage;
    }

    public void setUsage(String usage) {
        this.usage = usage;
    }

    public List<String> getAliases() {
        return this.aliases;
    }

    public void setAliases(List<String> aliases) {
        this.aliases = aliases;
    }

    public JavaPlugin getJavaPlugin() {
        return this.javaPlugin;
    }

    public void setJavaPlugin(JavaPlugin javaPlugin) {
        this.javaPlugin = javaPlugin;
    }

    public AbstractExecutor getExecutor() {
        return this.executor;
    }

    public void setExecutor(AbstractExecutor executor) {
        this.executor = executor;
    }
}
