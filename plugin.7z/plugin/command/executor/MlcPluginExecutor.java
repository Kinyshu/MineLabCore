package com.kinyshu.minelabcore.api.plugin.command.executor;

import com.kinyshu.minelabcore.api.command.abstracts.AbstractCommandExecutor;
import com.kinyshu.minelabcore.api.command.argument.CommandArgument;
import com.kinyshu.minelabcore.api.plugin.command.MlcPluginCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class MlcPluginExecutor extends AbstractCommandExecutor {

    public MlcPluginExecutor(MlcPluginCommand unloadPluginCommand) {
        super(unloadPluginCommand);
    }

    @Override
    public boolean onCommandExecuted(CommandArgument commandArgument) {

        String[] arguments = commandArgument.getArguments();
        CommandSender sender = commandArgument.getSender();

        if (sender.isOp() && sender.hasPermission("mlc.plugin")) {
            if (arguments.length > 0) {

                boolean status = false;
                final MlcPluginCommand pluginCommand = (MlcPluginCommand) this.getCommand();

                switch (arguments[0].toLowerCase()) {

                    case "load":
                        if (arguments.length == 2) {
                            status = pluginCommand.getMlcPlugins().loadPlugin(arguments[1]);
                            sender.sendMessage("§f[§aИнформация§f] §7Статус выключения плагина: §9" + Boolean.toString(status));
                        }
                        return true;

                    case "disable":
                        if (arguments.length == 2) {
                            status = pluginCommand.getMlcPlugins().disablePlugin(arguments[1]);
                            sender.sendMessage("§f[§aИнформация§f] §7Статус выключения плагина: §9" + Boolean.toString(status));
                        }
                        return true;

                    case "enable":
                        if (arguments.length == 2) {
                            status = pluginCommand.getMlcPlugins().enablePlugin(arguments[1]);
                            sender.sendMessage("§f[§aИнформация§f] §7Статус включения плагина: §9" + Boolean.toString(status));
                        }
                        return true;

                    case "list":
                        if (arguments.length == 1) {
                            List<JavaPlugin> pluginsList = pluginCommand.getMlcPlugins().getPluginsList();
                            sender.sendMessage("§f[§aИнформация§f] §7Список загруженных плагинов MineLabCore:");
                            pluginsList.forEach(plugin -> {
                                sender.sendMessage("§f[§aИнформация§f] §7" + plugin.getName());
                            });
                        }
                        return true;


                    default:
                        sender.sendMessage("§f[§cОшибка§f] §7Неизвестная команда");
                        return true;
                }
            }

            sender.sendMessage("§f[§9Использование§f] §7/mlcp <Действие> <Название плагина>");
        }

        return true;
    }
}
