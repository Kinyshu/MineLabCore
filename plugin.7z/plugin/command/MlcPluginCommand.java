package com.kinyshu.minelabcore.api.plugin.command;

import com.kinyshu.minelabcore.api.command.abstracts.AbstractCommand;
import com.kinyshu.minelabcore.api.plugin.MlcPlugin;
import com.kinyshu.minelabcore.api.plugin.command.executor.MlcPluginExecutor;

import java.util.List;

public class MlcPluginCommand extends AbstractCommand {

    private MlcPlugin mlcPlugins;

    public MlcPluginCommand(MlcPlugin mlcPlugins) {

        this.setMlcPlugins(mlcPlugins);

        this.setName("minelabcoreplugin");
        this.setDescription("Команда для управления плагинами линейки MineLab");
        this.setUsage("/mlcp <Действие> <Название плагина>");
        this.setAliases(List.of("mlcp", "mlcplugin"));

        this.setExecutor(new MlcPluginExecutor(this));
    }

    public MlcPlugin getMlcPlugins() {
        return this.mlcPlugins;
    }

    public void setMlcPlugins(MlcPlugin mlcPlugins) {
        this.mlcPlugins = mlcPlugins;
    }
}
