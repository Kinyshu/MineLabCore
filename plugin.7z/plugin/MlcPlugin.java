package com.kinyshu.minelabcore.api.plugin;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.event.Event;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredListener;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;

public class MlcPlugin {

    private List<JavaPlugin> pluginsList;

    public MlcPlugin() {
        this.setPluginsList(new ArrayList<>());
    }

    public void registerPlugin(JavaPlugin javaPlugin) {
        this.getPluginsList().add(javaPlugin);
    }

    public boolean disablePlugin(Plugin plugin) {

        if (plugin.isEnabled()) {
            Bukkit.getPluginManager().disablePlugin(plugin);
            return true;
        }

        return false;
    }

    public boolean disablePlugin(String pluginName) {
        for (JavaPlugin plugin : this.getPluginsList()) {
            if (pluginName.equalsIgnoreCase(plugin.getName()) && plugin.isEnabled()) {
                Bukkit.getPluginManager().disablePlugin(plugin);
                return true;
            }
        }
        return false;
    }

    public boolean enablePlugin(Plugin plugin) {

        if (!plugin.isEnabled()) {
            Bukkit.getPluginManager().enablePlugin(plugin);
            return true;
        }

        return false;
    }

    public boolean enablePlugin(String pluginName) {
        for (JavaPlugin plugin : this.getPluginsList()) {
            if (pluginName.equalsIgnoreCase(plugin.getName()) && !plugin.isEnabled()) {
                Bukkit.getPluginManager().enablePlugin(plugin);
                return true;
            }
        }
        return false;
    }

    public boolean loadPlugin(String fileName) {
        try {
            Plugin plugin = Bukkit.getPluginManager().loadPlugin(new File(fileName));
            plugin.onLoad();
            return this.enablePlugin(plugin);
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }

        return false;
    }

    private List<Plugin> getPlugins() throws NullPointerException {

        try {

            Field pluginsField = Bukkit.getPluginManager().getClass().getDeclaredField("plugins");
            pluginsField.setAccessible(true);

            return (List<Plugin>) pluginsField.get(Bukkit.getPluginManager());

        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }

    private Map<String, Plugin> getLookupNames() throws NullPointerException {
        try {

            Field lookupNamesField = Bukkit.getPluginManager().getClass().getDeclaredField("lookupNames");
            lookupNamesField.setAccessible(true);

            return (Map<String, Plugin>) lookupNamesField.get(Bukkit.getPluginManager());

        } catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }

    private Map<Event, SortedSet<RegisteredListener>> getListeners() {

        try {
            Field listenersField = Bukkit.getPluginManager().getClass().getDeclaredField("listeners");
            listenersField.setAccessible(true);

            return (Map<Event, SortedSet<RegisteredListener>>) listenersField.get(Bukkit.getPluginManager());

        } catch (Exception exception) {
            return null;
        }
    }

    private SimpleCommandMap getCommandMap() throws NullPointerException {
        try {
            final Field commandMapField = Bukkit.getPluginManager().getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);

            return (SimpleCommandMap) commandMapField.get(Bukkit.getPluginManager());
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }

    private Map<String, Command> getKnownCommands() throws NullPointerException {
        try {
            Field knownCommandsField = SimpleCommandMap.class.getDeclaredField("knownCommands");
            knownCommandsField.setAccessible(true);
            return (Map<String, Command>) knownCommandsField.get(Bukkit.getCommandMap());

        }
        catch (Exception exception) {
            exception.printStackTrace();
        }

        return null;
    }

    public List<JavaPlugin> getPluginsList() {
        return this.pluginsList;
    }

    private void setPluginsList(List<JavaPlugin> pluginsList) {
        this.pluginsList = pluginsList;
    }
}
