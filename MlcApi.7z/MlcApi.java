package com.kinyshu.minelabcore.api;

import com.kinyshu.minelabcore.api.command.abstracts.AbstractCommand;
import com.kinyshu.minelabcore.api.event.handler.ExtendedEventHandler;
import com.kinyshu.minelabcore.api.logger.Logger;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;

public class MlcApi {

    private MlcPlugin mlcPlugins;
    private static MlcApi mlcApi;

    private Logger logger;

    private List<AbstractCommand> registeredCommands;
    private List<ExtendedEventHandler> registeredEvents;

    public MlcApi() {
        this.setMlcApi(this);
        this.setMlcPlugins(new MlcPlugin());
        this.setRegisteredCommands(new ArrayList<>());
        this.setRegisteredEvents(new ArrayList<>());
    }

    public static MlcApi getMlcApi() {
        return MlcApi.mlcApi;
    }

    private void setMlcApi(MlcApi mlcApi) {
        MlcApi.mlcApi = mlcApi;
    }

   /* public MlcPlugin getMlcPlugins() {
        return mlcPlugins;
    }

    private void setMlcPlugins(MlcPlugin mlcPlugins) {
        this.mlcPlugins = mlcPlugins;
    }

    public void registerPlugin(JavaPlugin javaPlugin) {
        this.getMlcPlugins().registerPlugin(javaPlugin);
    }*/

    public List<AbstractCommand> getRegisteredCommands() {
        return this.registeredCommands;
    }

    private void setRegisteredCommands(List<AbstractCommand> registeredCommands) {
        this.registeredCommands = registeredCommands;
    }

    public List<ExtendedEventHandler> getRegisteredEvents() {
        return this.registeredEvents;
    }

    private void setRegisteredEvents(List<ExtendedEventHandler> registeredEvents) {
        this.registeredEvents = registeredEvents;
    }

    public void addCommand(AbstractCommand abstractCommand) {
        this.getRegisteredCommands().add(abstractCommand);
    }

    public Logger getLogger() {
        return this.logger;
    }

    public void setLogger(Logger logger) {
        this.logger = logger;
    }
}
